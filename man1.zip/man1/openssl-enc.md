## EXAMPLES

Just base64 encode a binary file:

 openssl base64 -in file.bin -out file.b64

Decode the same file

 openssl base64 -d -in file.b64 -out file.bin

Encrypt a file using AES-128 using a prompted password
and PBKDF2 key derivation:

 openssl enc -aes128 -pbkdf2 -in file.txt -out file.aes128

Decrypt a file using a supplied password:

 openssl enc -aes128 -pbkdf2 -d -in file.aes128 -out file.txt \
    -pass pass:<password>

Encrypt a file then base64 encode it (so it can be sent via mail for example)
using AES-256 in CTR mode and PBKDF2 key derivation:

 openssl enc -aes-256-ctr -pbkdf2 -a -in file.txt -out file.aes256

Base64 decode a file then decrypt it using a password supplied in a file:

 openssl enc -aes-256-ctr -pbkdf2 -d -a -in file.aes256 -out file.txt \
    -pass file:<passfile>

AES key wrapping:

 openssl enc -e -a -id-aes128-wrap-pad -K 000102030405060708090A0B0C0D0E0F -in file.bin
or
 openssl aes128-wrap-pad -e -a -K 000102030405060708090A0B0C0D0E0F -in file.bin
