## EXAMPLES

The documentation for the L<openssl-pkey(1)> command contains examples
equivalent to the ones listed here.

To encrypt a private key using triple DES:

 openssl ec -in key.pem -des3 -out keyout.pem

To convert a private key from PEM to DER format:

 openssl ec -in key.pem -outform DER -out keyout.der

To print out the components of a private key to standard output:

 openssl ec -in key.pem -text -noout

To just output the public part of a private key:

 openssl ec -in key.pem -pubout -out pubkey.pem

To change the parameters encoding to B<explicit>:

 openssl ec -in key.pem -param_enc explicit -out keyout.pem

To change the point conversion form to B<compressed>:

 openssl ec -in key.pem -conv_form compressed -out keyout.pem
