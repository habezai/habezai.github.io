## EXAMPLES

Convert a PKCS#7 file from PEM to DER:

 openssl pkcs7 -in file.pem -outform DER -out file.der

Output all certificates in a file:

 openssl pkcs7 -in file.pem -print_certs -out certs.pem
