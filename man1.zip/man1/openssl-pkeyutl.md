## EXAMPLES

Sign some data using a private key:

 openssl pkeyutl -sign -in file -inkey key.pem -out sig

Recover the signed data (e.g. if an RSA key is used):

 openssl pkeyutl -verifyrecover -in sig -inkey key.pem

Verify the signature (e.g. a DSA key):

 openssl pkeyutl -verify -in file -sigfile sig -inkey key.pem

Sign data using a message digest value (this is currently only valid for RSA):

 openssl pkeyutl -sign -in file -inkey key.pem -out sig -pkeyopt digest:sha256

Derive a shared secret value:

 openssl pkeyutl -derive -inkey key.pem -peerkey pubkey.pem -out secret

Hexdump 48 bytes of TLS1 PRF using digest B<SHA256> and shared secret and
seed consisting of the single byte 0xFF:

 openssl pkeyutl -kdf TLS1-PRF -kdflen 48 -pkeyopt md:SHA256 \
    -pkeyopt hexsecret:ff -pkeyopt hexseed:ff -hexdump

Derive a key using B<scrypt> where the password is read from command line:

 openssl pkeyutl -kdf scrypt -kdflen 16 -pkeyopt_passin pass \
    -pkeyopt hexsalt:aabbcc -pkeyopt N:16384 -pkeyopt r:8 -pkeyopt p:1

Derive using the same algorithm, but read key from environment variable MYPASS:

 openssl pkeyutl -kdf scrypt -kdflen 16 -pkeyopt_passin pass:env:MYPASS \
    -pkeyopt hexsalt:aabbcc -pkeyopt N:16384 -pkeyopt r:8 -pkeyopt p:1

Sign some data using an L<SM2(7)> private key and a specific ID:

 openssl pkeyutl -sign -in file -inkey sm2.key -out sig -rawin -digest sm3 \
    -pkeyopt distid:someid

Verify some data using an L<SM2(7)> certificate and a specific ID:

 openssl pkeyutl -verify -certin -in file -inkey sm2.cert -sigfile sig \
    -rawin -digest sm3 -pkeyopt distid:someid

Decrypt some data using a private key with OAEP padding using SHA256:

 openssl pkeyutl -decrypt -in file -inkey key.pem -out secret \
    -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha256

Create an ML-DSA key pair and sign data with a specific context string:

  $ openssl genpkey -algorithm ML-DSA-65 -out mldsa65.pem
  $ openssl pkeyutl -sign -in file.txt -inkey mldsa65.pem -out sig -pkeyopt context-string:example

Verify a signature using ML-DSA with the same context string:

  $ openssl pkeyutl -verify -in file.txt -inkey mldsa65.pem -sigfile sig -pkeyopt context-string:example

Generate an ML-KEM key pair and use it for encapsulation:

  $ openssl genpkey -algorithm ML-KEM-768 -out mlkem768.pem
  $ openssl pkey -in mlkem768.pem -pubout -out mlkem768_pub.pem
  $ openssl pkeyutl -encap -inkey mlkem768_pub.pem -pubin -out ciphertext -secret shared_secret.bin

Decapsulate a shared secret using an ML-KEM private key:

  $ openssl pkeyutl -decap -inkey mlkem768.pem -in ciphertext -secret decapsulated_secret.bin

Create an SLH-DSA key pair and sign data:

  $ openssl genpkey -algorithm SLH-DSA-SHA2-128s -out slh-dsa.pem
  $ openssl pkeyutl -sign -in file.txt -inkey slh-dsa.pem -out sig

Verify a signature using SLH-DSA:

  $ openssl pkeyutl -verify -in file.txt -inkey slh-dsa.pem -sigfile sig
