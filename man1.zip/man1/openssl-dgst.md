## EXAMPLES

To create a hex-encoded message digest of a file:

 openssl dgst -md5 -hex file.txt
 or
 openssl md5 file.txt

To sign a file using SHA-256 with binary file output:

 openssl dgst -sha256 -sign privatekey.pem -out signature.sign file.txt
 or
 openssl sha256 -sign privatekey.pem -out signature.sign file.txt

To verify a signature:

 openssl dgst -sha256 -verify publickey.pem \
 -signature signature.sign \
 file.txt