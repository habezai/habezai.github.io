## EXAMPLES

Convert a private key to PKCS#8 format using default parameters (AES with
256 bit key and B<hmacWithSHA256>):

 openssl pkcs8 -in key.pem -topk8 -out enckey.pem

Convert a private key to PKCS#8 unencrypted format:

 openssl pkcs8 -in key.pem -topk8 -nocrypt -out enckey.pem

Convert a private key to PKCS#5 v2.0 format using triple DES:

 openssl pkcs8 -in key.pem -topk8 -v2 des3 -out enckey.pem

Convert a private key to PKCS#5 v2.0 format using AES with 256 bits in CBC
mode and B<hmacWithSHA512> PRF:

 openssl pkcs8 -in key.pem -topk8 -v2 aes-256-cbc -v2prf hmacWithSHA512 -out enckey.pem

Convert a private key to PKCS#8 using a PKCS#5 1.5 compatible algorithm
(DES):

 openssl pkcs8 -in key.pem -topk8 -v1 PBE-MD5-DES -out enckey.pem

Convert a private key to PKCS#8 using a PKCS#12 compatible algorithm
(3DES):

 openssl pkcs8 -in key.pem -topk8 -out enckey.pem -v1 PBE-SHA1-3DES

Read a DER unencrypted PKCS#8 format private key:

 openssl pkcs8 -inform DER -nocrypt -in key.der -out key.pem

Convert a private key from any PKCS#8 encrypted format to traditional format:

 openssl pkcs8 -in pk8.pem -traditional -out key.pem

Convert a private key to PKCS#8 format, encrypting with AES-256 and with
one million iterations of the password:

 openssl pkcs8 -in key.pem -topk8 -v2 aes-256-cbc -iter 1000000 -out pk8.pem

## STANDARDS

Test vectors from this PKCS#5 v2.0 implementation were posted to the
pkcs-tng mailing list using triple DES, DES and RC2 with high iteration
counts, several people confirmed that they could decrypt the private
keys produced and therefore, it can be assumed that the PKCS#5 v2.0
implementation is reasonably accurate at least as far as these
algorithms are concerned.

The format of PKCS#8 DSA (and other) private keys is not well documented:
it is hidden away in PKCS#11 v2.01, section 11.9. OpenSSL's default DSA
PKCS#8 private key format complies with this standard.
