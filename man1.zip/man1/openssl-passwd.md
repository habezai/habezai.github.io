## EXAMPLES

  % openssl passwd -1 -salt xxxxxxxx password
  $1$xxxxxxxx$UYCIxa628.9qXjpQCjM4a.

  % openssl passwd -apr1 -salt xxxxxxxx password
  $apr1$xxxxxxxx$dxHfLAsjHkDRmG83UXe8K0

  % openssl passwd -aixmd5 -salt xxxxxxxx password
  xxxxxxxx$8Oaipk/GPKhC64w/YVeFD/
