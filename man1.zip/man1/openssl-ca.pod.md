## EXAMPLES

Note: these examples assume that the directory structure this command
assumes is already set up and the relevant files already exist. This
usually involves creating a CA certificate and private key with
L<openssl-req(1)>, a serial number file and an empty index file and
placing them in the relevant directories.

To use the sample configuration file below the directories F<demoCA>,
F<demoCA/private> and F<demoCA/newcerts> would be created. The CA
certificate would be copied to F<demoCA/cacert.pem> and its private
key to F<demoCA/private/cakey.pem>. A file F<demoCA/serial> would be
created containing for example "01" and the empty index file
F<demoCA/index.txt>.


Sign a certificate request:

 openssl ca -in req.pem -out newcert.pem

Sign a certificate request, using CA extensions:

 openssl ca -in req.pem -extensions v3_ca -out newcert.pem

Generate a CRL

 openssl ca -gencrl -out crl.pem

Sign several requests:

 openssl ca -infiles req1.pem req2.pem req3.pem

Certify a Netscape SPKAC:

 openssl ca -spkac spkac.txt

A sample SPKAC file (the SPKAC line has been truncated for clarity):

 SPKAC=MIG0MGAwXDANBgkqhkiG9w0BAQEFAANLADBIAkEAn7PDhCeV/xIxUg8V70YRxK2A5
 CN=Steve Test
 emailAddress=steve@openssl.org
 0.OU=OpenSSL Group
 1.OU=Another Group

A sample configuration file with the relevant sections for this command:

 [ ca ]
 default_ca      = CA_default            # The default ca section

 [ CA_default ]

 dir            = ./demoCA              # top dir
 database       = $dir/index.txt        # index file.
 new_certs_dir  = $dir/newcerts         # new certs dir

 certificate    = $dir/cacert.pem       # The CA cert
 serial         = $dir/serial           # serial no file
 #rand_serial    = yes                  # for random serial#'s
 private_key    = $dir/private/cakey.pem# CA private key

 default_days   = 365                   # how long to certify for
 default_crl_days= 30                   # how long before next CRL
 default_md     = sha256                # md to use

 policy         = policy_any            # default policy
 email_in_dn    = no                    # Don't add the email into cert DN

 name_opt       = ca_default            # Subject name display option
 cert_opt       = ca_default            # Certificate display option
 copy_extensions = none                 # Don't copy extensions from request

 [ policy_any ]
 countryName            = supplied
 stateOrProvinceName    = optional
 organizationName       = optional
 organizationalUnitName = optional
 commonName             = supplied
 emailAddress           = optional
