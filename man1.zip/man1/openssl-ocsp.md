## EXAMPLES

Create an OCSP request and write it to a file:

 openssl ocsp -issuer issuer.pem -cert c1.pem -cert c2.pem -reqout req.der

Send a query to an OCSP responder with URL http://ocsp.myhost.com/ save the
response to a file, print it out in text form, and verify the response:

 openssl ocsp -issuer issuer.pem -cert c1.pem -cert c2.pem \
     -url http://ocsp.myhost.com/ -resp_text -respout resp.der

Read in an OCSP response and print out text form:

 openssl ocsp -respin resp.der -text -noverify

OCSP server on port 8888 using a standard B<ca> configuration, and a separate
responder certificate. All requests and responses are printed to a file.

 openssl ocsp -index demoCA/index.txt -port 8888 -rsigner rcert.pem -CA demoCA/cacert.pem
        -text -out log.txt

As above but exit after processing one request:

 openssl ocsp -index demoCA/index.txt -port 8888 -rsigner rcert.pem -CA demoCA/cacert.pem
     -nrequest 1

Query status information using an internally generated request:

 openssl ocsp -index demoCA/index.txt -rsigner rcert.pem -CA demoCA/cacert.pem
     -issuer demoCA/cacert.pem -serial 1

Query status information using request read from a file, and write the response
to a second file.

 openssl ocsp -index demoCA/index.txt -rsigner rcert.pem -CA demoCA/cacert.pem
     -reqin req.der -respout resp.der
