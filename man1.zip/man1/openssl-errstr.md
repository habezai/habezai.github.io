## EXAMPLES

The error code:

 27594:error:2006D080:lib(32)::reason(128)::107:

can be displayed with:

 openssl errstr 2006D080

to produce the error message:

 error:2006D080:BIO routines::no such file
