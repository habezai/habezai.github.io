## EXAMPLES

The documentation for the L<openssl-genpkey(1)> and L<openssl-pkeyparam(1)>
commands contains examples equivalent to the ones listed here.

To create EC parameters with the group 'prime192v1':

  openssl ecparam -out ec_param.pem -name prime192v1

To create EC parameters with explicit parameters:

  openssl ecparam -out ec_param.pem -name prime192v1 -param_enc explicit

To validate given EC parameters:

  openssl ecparam -in ec_param.pem -check

To create EC parameters and a private key:

  openssl ecparam -out ec_key.pem -name prime192v1 -genkey

To change the point encoding to 'compressed':

  openssl ecparam -in ec_in.pem -out ec_out.pem -conv_form compressed

To print out the EC parameters to standard output:

  openssl ecparam -in ec_param.pem -noout -text
