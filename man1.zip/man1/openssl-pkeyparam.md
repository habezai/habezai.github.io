## EXAMPLES

Print out text version of parameters:

 openssl pkeyparam -in param.pem -text

## NOTES

There are no B<-inform> or B<-outform> options for this command because only
PEM format is supported because the key type is determined by the PEM headers.
