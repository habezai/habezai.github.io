## EXAMPLES

Convert a CRL file from PEM to DER:

 openssl crl -in crl.pem -outform DER -out crl.der

Output the text form of a DER encoded certificate:

 openssl crl -in crl.der -text -noout

## BUGS

Ideally it should be possible to create a CRL using appropriate options
and files too.
