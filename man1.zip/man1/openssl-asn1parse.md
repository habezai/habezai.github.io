## EXAMPLES

Parse a file:

 openssl asn1parse -in file.pem

Parse a DER file:

 openssl asn1parse -inform DER -in file.der

Generate a simple UTF8String:

 openssl asn1parse -genstr 'UTF8:Hello World'

Generate and write out a UTF8String, don't print parsed output:

 openssl asn1parse -genstr 'UTF8:Hello World' -noout -out utf8.der

Generate using a config file:

 openssl asn1parse -genconf asn1.cnf -noout -out asn1.der

Example config file:

 asn1=SEQUENCE:seq_sect

 [seq_sect]

 field1=BOOL:TRUE
 field2=EXP:0, UTF8:some random string