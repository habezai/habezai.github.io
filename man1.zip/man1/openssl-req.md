## EXAMPLES

Examine and verify certificate request:

 openssl req -in req.pem -text -verify -noout

Specify the cipher to be used for encrypting the private key:

 openssl req -newkey rsa:2048 -keyout privatekey.pem -out request.csr -cipher aes-256-cbc

Create a private key and then generate a certificate request from it:

 openssl genrsa -out key.pem 2048
 openssl req -new -key key.pem -out req.pem

The same but just using req:

 openssl req -newkey rsa:2048 -keyout key.pem -out req.pem

Generate a self-signed root certificate:

 openssl req -x509 -newkey rsa:2048 -keyout key.pem -out req.pem

Example of a file pointed to by the B<oid_file> option:

 1.2.3.4        shortName       A longer Name
 1.2.3.6        otherName       Other longer Name

Example of a section pointed to by B<oid_section> making use of variable
expansion:

 testoid1=1.2.3.5
 testoid2=${testoid1}.6

Sample configuration file prompting for field values:

 [ req ]
 default_bits           = 2048
 default_keyfile        = privkey.pem
 distinguished_name     = req_distinguished_name
 attributes             = req_attributes
 req_extensions         = v3_ca

 dirstring_type = nombstr

 [ req_distinguished_name ]
 countryName                    = Country Name (2 letter code)
 countryName_default            = AU
 countryName_min                = 2
 countryName_max                = 2

 localityName                   = Locality Name (eg, city)

 organizationalUnitName         = Organizational Unit Name (eg, section)

 commonName                     = Common Name (eg, YOUR name)
 commonName_max                 = 64

 emailAddress                   = Email Address
 emailAddress_max               = 40

 [ req_attributes ]
 challengePassword              = A challenge password
 challengePassword_min          = 4
 challengePassword_max          = 20

 [ v3_ca ]

 subjectKeyIdentifier=hash
 authorityKeyIdentifier=keyid:always,issuer:always
 basicConstraints = critical, CA:true

Sample configuration containing all field values:


 [ req ]
 default_bits           = 2048
 default_keyfile        = keyfile.pem
 distinguished_name     = req_distinguished_name
 attributes             = req_attributes
 prompt                 = no
 output_password        = mypass

 [ req_distinguished_name ]
 C                      = GB
 ST                     = Test State or Province
 L                      = Test Locality
 O                      = Organization Name
 OU                     = Organizational Unit Name
 CN                     = Common Name
 emailAddress           = test@email.address

 [ req_attributes ]
 challengePassword              = A challenge password

Example of giving the most common attributes (subject and extensions)
on the command line:

 openssl req -new -subj "/C=GB/CN=foo" \
                  -addext "subjectAltName = DNS:foo.co.uk" \
                  -addext "certificatePolicies = 1.2.3.4" \
                  -newkey rsa:2048 -keyout key.pem -out req.pem

