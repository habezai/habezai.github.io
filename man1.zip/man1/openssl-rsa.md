## EXAMPLES

The documentation for the L<openssl-pkey(1)> command contains examples
equivalent to the ones listed here.

To remove the pass phrase on an RSA private key:

 openssl rsa -in key.pem -out keyout.pem

To encrypt a private key using triple DES:

 openssl rsa -in key.pem -des3 -out keyout.pem

To convert a private key from PEM to DER format:

 openssl rsa -in key.pem -outform DER -out keyout.der

To print out the components of a private key to standard output:

 openssl rsa -in key.pem -text -noout

To just output the public part of a private key:

 openssl rsa -in key.pem -pubout -out pubkey.pem

Output the public part of a private key in B<RSAPublicKey> format:

 openssl rsa -in key.pem -RSAPublicKey_out -out pubkey.pem
