## EXAMPLES

Create a PKCS#7 structure from a certificate and CRL:

 openssl crl2pkcs7 -in crl.pem -certfile cert.pem -out p7.pem

Creates a PKCS#7 structure in DER format with no CRL from several
different certificates:

 openssl crl2pkcs7 -nocrl -certfile newcert.pem
        -certfile demoCA/cacert.pem -outform DER -out p7.der
