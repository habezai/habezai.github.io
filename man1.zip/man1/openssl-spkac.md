## EXAMPLES

Print out the contents of an SPKAC:

 openssl spkac -in spkac.cnf

Verify the signature of an SPKAC:

 openssl spkac -in spkac.cnf -noout -verify

Create an SPKAC using the challenge string "hello":

 openssl spkac -key key.pem -challenge hello -out spkac.cnf

Example of an SPKAC, (long lines split up for clarity):

 SPKAC=MIG5MGUwXDANBgkqhkiG9w0BAQEFAANLADBIAkEA\
 1cCoq2Wa3Ixs47uI7FPVwHVIPDx5yso105Y6zpozam135a\
 8R0CpoRvkkigIyXfcCjiVi5oWk+6FfPaD03uPFoQIDAQAB\
 FgVoZWxsbzANBgkqhkiG9w0BAQQFAANBAFpQtY/FojdwkJ\
 h1bEIYuc2EeM2KHTWPEepWYeawvHD0gQ3DngSC75YCWnnD\
 dq+NQ3F+X4deMx9AaEglZtULwV4=
