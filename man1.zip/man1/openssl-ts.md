## EXAMPLES

All the examples below presume that B<OPENSSL_CONF> is set to a proper
configuration file, e.g. the example configuration file
F<openssl/apps/openssl.cnf> will do.

### Timestamp Request

To create a timestamp request for F<design1.txt> with SHA-256 digest,
without nonce and policy, and without requirement for a certificate
in the response:

  openssl ts -query -data design1.txt -no_nonce \
        -out design1.tsq

To create a similar timestamp request with specifying the message imprint
explicitly:

  openssl ts -query -digest b7e5d3f93198b38379852f2c04e78d73abdd0f4b \
         -no_nonce -out design1.tsq

To print the content of the previous request in human readable format:

  openssl ts -query -in design1.tsq -text

To create a timestamp request which includes the SHA-512 digest
of F<design2.txt>, requests the signer certificate and nonce, and
specifies a policy id (assuming the tsa_policy1 name is defined in the
OID section of the config file):

  openssl ts -query -data design2.txt -sha512 \
        -tspolicy tsa_policy1 -cert -out design2.tsq

### Timestamp Response

Before generating a response a signing certificate must be created for
the TSA that contains the B<timeStamping> critical extended key usage extension
without any other key usage extensions. You can add this line to the
user certificate section of the config file to generate a proper certificate;

   extendedKeyUsage = critical,timeStamping

See L<openssl-req(1)>, L<openssl-ca(1)>, and L<openssl-x509(1)> for
instructions. The examples below assume that F<cacert.pem> contains the
certificate of the CA, F<tsacert.pem> is the signing certificate issued
by F<cacert.pem> and F<tsakey.pem> is the private key of the TSA.

To create a timestamp response for a request:

  openssl ts -reply -queryfile design1.tsq -inkey tsakey.pem \
        -signer tsacert.pem -out design1.tsr

If you want to use the settings in the config file you could just write:

  openssl ts -reply -queryfile design1.tsq -out design1.tsr

To print a timestamp reply to stdout in human readable format:

  openssl ts -reply -in design1.tsr -text

To create a timestamp token instead of timestamp response:

  openssl ts -reply -queryfile design1.tsq -out design1_token.der -token_out

To print a timestamp token to stdout in human readable format:

  openssl ts -reply -in design1_token.der -token_in -text -token_out

To extract the timestamp token from a response:

  openssl ts -reply -in design1.tsr -out design1_token.der -token_out

To add 'granted' status info to a timestamp token thereby creating a
valid response:

  openssl ts -reply -in design1_token.der -token_in -out design1.tsr

### Timestamp Verification

To verify a timestamp reply against a request:

  openssl ts -verify -queryfile design1.tsq -in design1.tsr \
        -CAfile cacert.pem -untrusted tsacert.pem

To verify a timestamp reply that includes the certificate chain:

  openssl ts -verify -queryfile design2.tsq -in design2.tsr \
        -CAfile cacert.pem

To verify a timestamp token against the original data file:

  openssl ts -verify -data design2.txt -in design2.tsr \
        -CAfile cacert.pem

To verify a timestamp token against a message imprint:

  openssl ts -verify -digest b7e5d3f93198b38379852f2c04e78d73abdd0f4b \
         -in design2.tsr -CAfile cacert.pem

You could also look at the 'test' directory for more examples.
