## EXAMPLES

Calculate the mac of a FIPS module F<fips.so> and run a FIPS self test
for the module, and save the F<fips.cnf> configuration file:

 openssl fipsinstall -module ./fips.so -out fips.cnf -provider_name fips

Verify that the configuration file F<fips.cnf> contains the correct info:

 openssl fipsinstall -module ./fips.so -in fips.cnf  -provider_name fips -verify

Corrupt any self tests which have the description C<SHA1>:

 openssl fipsinstall -module ./fips.so -out fips.cnf -provider_name fips \
         -corrupt_desc 'SHA1'

Validate that the fips module can be loaded from a base configuration file:

 export OPENSSL_CONF_INCLUDE=<path of configuration files>
 export OPENSSL_MODULES=<provider-path>
 openssl fipsinstall -config' 'default.cnf'
