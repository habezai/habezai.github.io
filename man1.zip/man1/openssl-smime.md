## EXAMPLES

Create a cleartext signed message:

 openssl smime -sign -in message.txt -text -out mail.msg \
        -signer mycert.pem

Create an opaque signed message:

 openssl smime -sign -in message.txt -text -out mail.msg -nodetach \
        -signer mycert.pem

Create a signed message, include some additional certificates and
read the private key from another file:

 openssl smime -sign -in in.txt -text -out mail.msg \
        -signer mycert.pem -inkey mykey.pem -certfile mycerts.pem

Create a signed message with two signers:

 openssl smime -sign -in message.txt -text -out mail.msg \
        -signer mycert.pem -signer othercert.pem

Send a signed message under Unix directly to sendmail, including headers:

 openssl smime -sign -in in.txt -text -signer mycert.pem \
        -from steve@openssl.org -to someone@somewhere \
        -subject "Signed message" | sendmail someone@somewhere

Verify a message and extract the signer's certificate if successful:

 openssl smime -verify -in mail.msg -signer user.pem -out signedtext.txt

Send encrypted mail using triple DES:

 openssl smime -encrypt -in in.txt -out mail.msg -from steve@openssl.org \
        -to someone@somewhere -subject "Encrypted message" \
        -des3 user.pem

Sign and encrypt mail:

 openssl smime -sign -in ml.txt -signer my.pem -text \
        | openssl smime -encrypt -out mail.msg \
        -from steve@openssl.org -to someone@somewhere \
        -subject "Signed and Encrypted message" -des3 user.pem

Note: the encryption command does not include the B<-text> option because the
message being encrypted already has MIME headers.

Decrypt mail:

 openssl smime -decrypt -in mail.msg -recip mycert.pem -inkey key.pem

The output from Netscape form signing is a PKCS#7 structure with the
detached signature format. You can use this program to verify the
signature by line wrapping the base64 encoded structure and surrounding
it with:

 -----BEGIN PKCS7-----
 -----END PKCS7-----

and using the command:

 openssl smime -verify -inform PEM -in signature.pem -content content.txt

Alternatively you can base64 decode the signature and use:

 openssl smime -verify -inform DER -in signature.der -content content.txt

Create an encrypted message using 128 bit Camellia:

 openssl smime -encrypt -in plain.txt -camellia128 -out mail.msg cert.pem

Add a signer to an existing message:

 openssl smime -resign -in mail.msg -signer newsign.pem -out mail2.msg
