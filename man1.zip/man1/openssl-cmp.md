## EXAMPLES

### Simple examples using the default OpenSSL configuration file

This CMP client implementation comes with demonstrative CMP sections
in the example configuration file F<openssl/apps/openssl.cnf>,
which can be used to interact conveniently with the Insta Demo CA.

In order to enroll an initial certificate from that CA it is sufficient
to issue the following shell commands.

  export OPENSSL_CONF=/path/to/openssl/apps/openssl.cnf

=begin comment

  wget 'http://pki.certificate.fi:8081/install-ca-cert.html/ca-certificate.crt\
        ?ca-id=632&download-certificate=1' -O insta.ca.crt

=end comment

  openssl genrsa -out insta.priv.pem
  openssl cmp -section insta

This should produce the file F<insta.cert.pem> containing a new certificate
for the private key held in F<insta.priv.pem>.
It can be viewed using, e.g.,

  openssl x509 -noout -text -in insta.cert.pem

In case the network setup requires using an HTTP proxy it may be given as usual
via the environment variable B<http_proxy> or via the B<-proxy> option in the
configuration file or the CMP command-line argument B<-proxy>, for example

  -proxy http://192.168.1.1:8080

In the Insta Demo CA scenario both clients and the server may use the pre-shared
secret I<insta> and the reference value I<3078> to authenticate to each other.

Alternatively, CMP messages may be protected in signature-based manner,
where the trust anchor in this case is F<insta.ca.crt>
and the client may use any certificate already obtained from that CA,
as specified in the B<[signature]> section of the example configuration.
This can be used in combination with the B<[insta]> section simply by

  openssl cmp -section insta,signature

By default the CMP IR message type is used, yet CR works equally here.
This may be specified directly at the command line:

  openssl cmp -section insta -cmd cr

or by referencing in addition the B<[cr]> section of the example configuration:

  openssl cmp -section insta,cr

In order to update the enrolled certificate one may call

  openssl cmp -section insta,kur,signature

using signature-based protection with the certificate that is to be updated.
For certificate updates, MAC-based protection should generally not be used.

In a similar way any previously enrolled certificate may be revoked by

  openssl cmp -section insta,rr -trusted insta.ca.crt

or

  openssl cmp -section insta,rr,signature

Many more options can be given in the configuration file
and/or on the command line.
For instance, the B<-reqexts> CLI option may refer to a section in the
configuration file defining X.509 extensions to use in certificate requests,
such as C<v3_req> in F<openssl/apps/openssl.cnf>:

  openssl cmp -section insta,cr -reqexts v3_req

### Certificate enrollment

The following examples do not make use of a configuration file at first.
They assume that a CMP server can be contacted on the local TCP port 80
and accepts requests under the alias I</pkix/>.

For enrolling its very first certificate the client generates a client key
and sends an initial request message to the local CMP server
using a pre-shared secret key for mutual authentication.
In this example the client does not have the CA certificate yet,
so we specify the name of the CA with the B<-recipient> option
and save any CA certificates that we may receive in the C<capubs.pem> file.

In below command line usage examples the C<\> at line ends is used just
for formatting; each of the command invocations should be on a single line.

  openssl genrsa -out cl_key.pem
  openssl cmp -cmd ir -server 127.0.0.1:80/pkix/ -recipient "/CN=CMPserver" \
    -ref 1234 -secret pass:1234-5678 \
    -newkey cl_key.pem -subject "/CN=MyName" \
    -cacertsout capubs.pem -certout cl_cert.pem

### Certificate update

Then, when the client certificate and its related key pair needs to be updated,
the client can send a key update request taking the certs in C<capubs.pem>
as trusted for authenticating the server and using the previous cert and key
for its own authentication.
Then it can start using the new cert and key.

  openssl genrsa -out cl_key_new.pem
  openssl cmp -cmd kur -server 127.0.0.1:80/pkix/ \
    -trusted capubs.pem \
    -cert cl_cert.pem -key cl_key.pem \
    -newkey cl_key_new.pem -certout cl_cert.pem
  cp cl_key_new.pem cl_key.pem

This command sequence can be repeated as often as needed.

### Requesting information from CMP server

Requesting "all relevant information" with an empty General Message.
This prints information about all received ITAV B<infoType>s to stdout.

  openssl cmp -cmd genm -server 127.0.0.1/pkix/ -recipient "/CN=CMPserver" \
    -ref 1234 -secret pass:1234-5678

### Using a custom configuration file

For CMP client invocations, in particular for certificate enrollment,
usually many parameters need to be set, which is tedious and error-prone to do
on the command line.
Therefore, the client offers the possibility to read
options from sections of the OpenSSL config file, usually called F<openssl.cnf>.
The values found there can still be extended and even overridden by any
subsequently loaded sections and on the command line.

After including in the configuration file the following sections:

  [cmp]
  server = 127.0.0.1
  path = pkix/
  trusted = capubs.pem
  cert = cl_cert.pem
  key = cl_key.pem
  newkey = cl_key.pem
  certout = cl_cert.pem

  [init]
  recipient = "/CN=CMPserver"
  trusted =
  cert =
  key =
  ref = 1234
  secret = pass:1234-5678-1234-567
  subject = "/CN=MyName"
  cacertsout = capubs.pem

the above enrollment transactions reduce to

  openssl cmp -section cmp,init
  openssl cmp -cmd kur -newkey cl_key_new.pem

and the above transaction using a general message reduces to

  openssl cmp -section cmp,init -cmd genm
