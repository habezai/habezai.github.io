## EXAMPLES

Dump the configuration file I<my.conf> processing all B<.include> directives to the
file B<result.conf>

 openssl configutl -config my.conf -out result.conf
