## EXAMPLES

Parse a PKCS#12 file and output it to a PEM file:

 openssl pkcs12 -in file.p12 -out file.pem

Output only client certificates to a file:

 openssl pkcs12 -in file.p12 -clcerts -out file.pem

Don't encrypt the private key:

 openssl pkcs12 -in file.p12 -out file.pem -noenc

Print some info about a PKCS#12 file:

 openssl pkcs12 -in file.p12 -info -noout

Print some info about a PKCS#12 file in legacy mode:

 openssl pkcs12 -in file.p12 -info -noout -legacy

Create a PKCS#12 file from a PEM file that may contain a key and certificates:

 openssl pkcs12 -export -in file.pem -out file.p12 -name "My PSE"

Include some extra certificates:

 openssl pkcs12 -export -in file.pem -out file.p12 -name "My PSE" \
  -certfile othercerts.pem

Export a PKCS#12 file with data from a certificate PEM file and from a further
PEM file containing a key, with default algorithms as in the legacy provider:

 openssl pkcs12 -export -in cert.pem -inkey key.pem -out file.p12 -legacy
