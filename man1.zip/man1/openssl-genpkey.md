## EXAMPLES

Generate an RSA private key using default parameters:

 openssl genpkey -algorithm RSA -out key.pem

Encrypt output private key using 128 bit AES and the passphrase "hello":

 openssl genpkey -algorithm RSA -out key.pem -aes-128-cbc -pass pass:hello

Generate a 2048 bit RSA key using 3 as the public exponent:

 openssl genpkey -algorithm RSA -out key.pem \
     -pkeyopt rsa_keygen_bits:2048 -pkeyopt rsa_keygen_pubexp:3

Generate 2048 bit DSA parameters that can be validated: The output values for
gindex and seed are required for key validation purposes and are not saved to
the output pem file).

 openssl genpkey -genparam -algorithm DSA -out dsap.pem -pkeyopt pbits:2048 \
     -pkeyopt qbits:224 -pkeyopt digest:SHA256 -pkeyopt gindex:1 -text

Generate DSA key from parameters:

 openssl genpkey -paramfile dsap.pem -out dsakey.pem

Generate 4096 bit DH Key using safe prime group ffdhe4096:

 openssl genpkey -algorithm DH -out dhkey.pem -pkeyopt group:ffdhe4096

Generate 2048 bit X9.42 DH key with 256 bit subgroup using RFC5114 group3:

 openssl genpkey -algorithm DHX -out dhkey.pem -pkeyopt dh_rfc5114:3

Generate a DH key using a DH parameters file:

 openssl genpkey -paramfile dhp.pem -out dhkey.pem

Output DH parameters for safe prime group ffdhe2048:

 openssl genpkey -genparam -algorithm DH -out dhp.pem -pkeyopt group:ffdhe2048

Output 2048 bit X9.42 DH parameters with 224 bit subgroup using RFC5114 group2:

 openssl genpkey -genparam -algorithm DHX -out dhp.pem -pkeyopt dh_rfc5114:2

Output 2048 bit X9.42 DH parameters with 224 bit subgroup using FIP186-4 keygen:

 openssl genpkey -genparam -algorithm DHX -out dhp.pem -text \
     -pkeyopt pbits:2048 -pkeyopt qbits:224 -pkeyopt digest:SHA256 \
     -pkeyopt gindex:1 -pkeyopt dh_paramgen_type:2

Output 1024 bit X9.42 DH parameters with 160 bit subgroup using FIP186-2 keygen:

 openssl genpkey -genparam -algorithm DHX -out dhp.pem -text \
     -pkeyopt pbits:1024 -pkeyopt qbits:160 -pkeyopt digest:SHA1 \
     -pkeyopt gindex:1 -pkeyopt dh_paramgen_type:1

Output 2048 bit DH parameters:

 openssl genpkey -genparam -algorithm DH -out dhp.pem \
     -pkeyopt dh_paramgen_prime_len:2048

Output 2048 bit DH parameters using a generator:

 openssl genpkey -genparam -algorithm DH -out dhpx.pem \
     -pkeyopt dh_paramgen_prime_len:2048 \
     -pkeyopt dh_paramgen_type:1

Generate EC parameters:

 openssl genpkey -genparam -algorithm EC -out ecp.pem \
        -pkeyopt ec_paramgen_curve:secp384r1 \
        -pkeyopt ec_param_enc:named_curve

Generate EC key from parameters:

 openssl genpkey -paramfile ecp.pem -out eckey.pem

Generate EC key directly:

 openssl genpkey -algorithm EC -out eckey.pem \
        -pkeyopt ec_paramgen_curve:P-384 \
        -pkeyopt ec_param_enc:named_curve

Generate an X25519 private key:

 openssl genpkey -algorithm X25519 -out xkey.pem

Generate an ED448 private key:

 openssl genpkey -algorithm ED448 -out xkey.pem

Generate an ML-DSA-65 private key:

 openssl genpkey -algorithm ML-DSA-65 -out ml-dsa-key.pem

Generate an ML-KEM-768 private key:

 openssl genpkey -algorithm ML-KEM-768 -out ml-kem-key.pem
