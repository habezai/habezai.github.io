## EXAMPLES

Output the certificates in a Netscape certificate sequence

 openssl nseq -in nseq.pem -out certs.pem

Create a Netscape certificate sequence

 openssl nseq -in certs.pem -toseq -out nseq.pem
