## EXAMPLES

To remove the pass phrase on a private key:

 openssl pkey -in key.pem -out keyout.pem

To encrypt a private key using triple DES:

 openssl pkey -in key.pem -des3 -out keyout.pem

To convert a private key from PEM to DER format:

 openssl pkey -in key.pem -outform DER -out keyout.der

To print out the components of a private key to standard output:

 openssl pkey -in key.pem -text -noout

To print out the public components of a private key to standard output:

 openssl pkey -in key.pem -text_pub -noout

To just output the public part of a private key:

 openssl pkey -in key.pem -pubout -out pubkey.pem

To change the EC parameters encoding to B<explicit>:

 openssl pkey -in key.pem -ec_param_enc explicit -out keyout.pem

To change the EC point conversion form to B<compressed>:

 openssl pkey -in key.pem -ec_conv_form compressed -out keyout.pem
