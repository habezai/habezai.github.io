## EXAMPLES

Note: in these examples the '\' means the example should be all on one
line.

Print the contents of a certificate:

 openssl x509 -in cert.pem -noout -text

Print the "Subject Alternative Name" extension of a certificate:

 openssl x509 -in cert.pem -noout -ext subjectAltName

Print more extensions of a certificate:

 openssl x509 -in cert.pem -noout -ext subjectAltName,nsCertType

Print the certificate serial number:

 openssl x509 -in cert.pem -noout -serial

Print the certificate subject name:

 openssl x509 -in cert.pem -noout -subject

Print the certificate subject name in RFC2253 form:

 openssl x509 -in cert.pem -noout -subject -nameopt RFC2253

Print the certificate subject name in oneline form on a terminal
supporting UTF8:

 openssl x509 -in cert.pem -noout -subject -nameopt oneline,-esc_msb

Print the certificate SHA1 fingerprint:

 openssl x509 -sha1 -in cert.pem -noout -fingerprint

Convert a certificate from PEM to DER format:

 openssl x509 -in cert.pem -inform PEM -out cert.der -outform DER

Convert a certificate to a certificate request:

 openssl x509 -x509toreq -in cert.pem -out req.pem -key key.pem

Convert a certificate request into a self-signed certificate using
extensions for a CA:

 openssl x509 -req -in careq.pem -extfile openssl.cnf -extensions v3_ca \
        -key key.pem -out cacert.pem

Sign a certificate request using the CA certificate above and add user
certificate extensions:

 openssl x509 -req -in req.pem -extfile openssl.cnf -extensions v3_usr \
        -CA cacert.pem -CAkey key.pem -CAcreateserial

Set a certificate to be trusted for SSL client use and change set its alias to
"Steve's Class 1 CA"

 openssl x509 -in cert.pem -addtrust clientAuth \
        -setalias "Steve's Class 1 CA" -out trust.pem

Check if any certificates in a chain are due to expire within the next 30 days
(returns zero if none will expire, nonzero if any will expire):

 openssl x509 -in chain.pem -multi -checkend $[3600*24*30] \
        && echo 'perform renewal' || echo 'renewal unnecessary'

## NOTES

The conversion to UTF8 format used with the name options assumes that
T61Strings use the ISO8859-1 character set. This is wrong but Netscape
and MSIE do this as do many certificates. So although this is incorrect
it is more likely to print the majority of certificates correctly.

The B<-email> option searches the subject name and the subject alternative
name extension. Only unique email addresses will be printed out: it will
not print the same address more than once.
